package org.zerock.Data;

import lombok.Data;

@Data //setter, getter, toString, equals, hashcode
public class SampleDTO {
	private String name;
	private int age;

}
